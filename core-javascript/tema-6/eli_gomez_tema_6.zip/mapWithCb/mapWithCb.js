function mapWithCb(array, callback) {
  return array.map(callback);
}

module.exports = mapWithCb;
